import os
import cv2
import tkinter as tk
from PIL import Image, ImageTk

# 미리 지정된 폴더 경로
FOLDER_PATH = "uploaded_file"  # 실제 경로로 변경해 주세요.

def get_video_thumbnails(folder_path):
    thumbnails = []
    for file_name in os.listdir(folder_path):
        if file_name.endswith(('.mp4', '.avi', '.mkv', '.mov')):
            video_path = os.path.join(folder_path, file_name)
            cap = cv2.VideoCapture(video_path)
            ret, frame = cap.read()
            if ret:
                thumbnail = cv2.resize(frame, (160, 90))  # 썸네일 크기 설정
                thumbnails.append((file_name, thumbnail))
            cap.release()
    return thumbnails

def display_thumbnails(thumbnails):
    for widget in frame.winfo_children():
        widget.destroy()
    
    for idx, (file_name, thumbnail) in enumerate(thumbnails):
        image = Image.fromarray(cv2.cvtColor(thumbnail, cv2.COLOR_BGR2RGB))
        image_tk = ImageTk.PhotoImage(image)
        
        label = tk.Label(frame, image=image_tk)
        label.image = image_tk
        label.grid(row=idx // 4, column=idx % 4, padx=10, pady=10)
        
        text = tk.Label(frame, text=file_name + '\nDeepfake 안전', wraplength=160)
        text.grid(row=idx // 4 + 1, column=idx % 4, padx=10, pady=10)

root = tk.Tk()
root.title("Video Viewer")

frame = tk.Frame(root)
frame.pack(pady=20)

thumbnails = get_video_thumbnails(FOLDER_PATH)
display_thumbnails(thumbnails)

root.mainloop()
